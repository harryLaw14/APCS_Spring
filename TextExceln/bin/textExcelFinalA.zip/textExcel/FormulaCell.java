//Brandon Nguyen, 2nd Period
package textExcel;

public class FormulaCell extends RealCell{
	
	private String formula;

	public FormulaCell(String formula) {
		// TODO Auto-generated constructor stub
		this.formula = formula;
		setRealCell(formula);
	}

	public double getDoubleValue(){
		return 0.0;
	}
}
